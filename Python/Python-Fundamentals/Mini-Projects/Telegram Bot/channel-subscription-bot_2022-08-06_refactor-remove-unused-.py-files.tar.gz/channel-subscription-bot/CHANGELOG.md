# Changelog

- 2022-08-06 refactor: remove unused /*.py files
- 2022-08-06 feat: allow disable logging to Telegram chat
- 2022-08-06 refactor: change invoice title/description
- 2022-08-05 feat: add /admin panel and /help for owner
- 2022-08-05 feat: send generated invite link after payment
- 2022-08-03 feat: add chat_id handler for /id command
- 2022-08-03 feat: add handler: purchase
- 2022-08-03 feat: add owner handler with /database command
- 2022-08-01 feat: add bot module
- 2022-08-01 feat: add aiogram example payments.py
- 2022-08-01 feat: initial commit

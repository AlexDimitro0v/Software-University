cfg = {
    'bot_token': '123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11',
    # owner ID or 'username'
    'owner': 'owner_username',
    # get chat ID by using /id command,
    # chat 'username' can't be used for channel_id nor log_chat_id
    # set 'log_chat_id' to None to disable logging to Telegram chat
    'channel_id': -100123456789,
    'log_chat_id': -100234567890
}
